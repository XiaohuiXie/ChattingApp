package com.example.prof;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class TestActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.testactivity);

        final Button button4 = findViewById(R.id.button4);

        button4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent ac4 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(ac4);
            }
        });
    }
}
