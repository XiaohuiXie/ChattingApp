package com.example.prof;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button1 = findViewById(R.id.button1);
        final Button button2 = findViewById(R.id.button2);
        final ImageButton button3 = findViewById(R.id.button3);

        button1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent ac1 = new Intent(getApplicationContext(), TestActivity.class);
                startActivity(ac1);
            }
        });

        button2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent ac2 = new Intent(getApplicationContext(), TestActivity.class);
                startActivity(ac2);
            }
        });

        button3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent ac3 = new Intent(getApplicationContext(), TestActivity.class);
                startActivity(ac3);
            }
        });

      
    }
}
